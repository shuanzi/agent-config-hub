---
name: Smoke Skill
description: A tiny skill for L3 smoke tests.
---
# Smoke Skill

# Prototype Instructions

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

## 本原型的交互约定

用户于 2026-10-14 要求将“来自全局”的“跟随”操作改为直接勾选／取消勾选。矩阵中的使用状态统一使用原生复选框；来源文字独立保留。勾选表示当前范围使用，取消来自全局的勾选表示仅在本项目停用，不能改动全局配置或其他项目。重新勾选恢复使用，不先打开选项弹窗。未核对的原生停用能力保留原状态、禁用该复选框，并通过邻近说明入口解释原因。此约定只适用于这份模拟设计原型。

2026-10-14 用户批准 Codex 项目启动入口：项目列标明仅经此入口生效，启动对话框使用已保存排除项，当前项目草稿阻止启动。OpenCode 项目排除使用原生权限；角色覆盖等限制明确显示。原型只模拟，不启动真实进程。所选布局不重新设计，设计源与预览清单同步更新。

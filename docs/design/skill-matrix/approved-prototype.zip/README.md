# Skills 项目 × Agent 矩阵原型

用户已选定此方向，并确认直接复选框交互。当前版本增加 Codex 项目启动对话框和 OpenCode 角色权限限制样例。全部数据、配置应用及启动均为模拟；刷新恢复样例。

```sh
npm ci
npm run dev -- --host 127.0.0.1 --port 4175
npm test
npm run build
```

设计与能力边界见 design-notes.md，QA 范围见 design-qa.md。selected-concept.png 保留所选初始概念。组合等早期探索不等于正式产品能力；实际能力及验证以 Agent Config Manager 仓库产品说明、矩阵设计入口与验收记录为准。
